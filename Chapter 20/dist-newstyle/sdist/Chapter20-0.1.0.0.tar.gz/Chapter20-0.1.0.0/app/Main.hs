-- HC20T4: countChars with State Monad
import Control.Monad.State

type Counter = State Int

countChar :: Char -> Char -> Counter ()
countChar target current = 
    when (target == current) $ modify (+1)

countChars :: Char -> String -> Counter Int
countChars target str = do
    mapM_ (countChar target) str
    get

-- Alternative: using foldM
countChars' :: Char -> String -> Counter Int
countChars' target str = foldM increment 0 str
  where
    increment :: Int -> Char -> Counter Int
    increment count c = return $ if c == target then count + 1 else count

main :: IO ()
main = do
    putStrLn "=== HC20T4: countChars with State Monad ==="
    let str = "hello world"
    let target = 'l'
    let (count, _) = runState (countChars target str) 0
    let (count', _) = runState (countChars' target str) 0
    putStrLn $ "String: " ++ show str
    putStrLn $ "Count of '" ++ [target] ++ "': " ++ show count
    putStrLn $ "Alternative count: " ++ show count'